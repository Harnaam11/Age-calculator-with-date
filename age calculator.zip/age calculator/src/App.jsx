import React from "react";
import Home from "./pages/Home";

function App() {
  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <Home />
    </div>
  );
}

export default App;
